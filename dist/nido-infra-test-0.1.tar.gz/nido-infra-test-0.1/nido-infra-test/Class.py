class Teste1:
    x = 5