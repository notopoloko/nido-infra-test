class Teste2:
    x = 5